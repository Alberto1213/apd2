#include <mpi.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>	

int prime(int n)
{
    if (n==0 || n==1)
        return 0;
    
    int ok=1;    
    if (!(n==0 || n==1))
        for(int i=2;i*i<=n;i++)
            if(n%i==0)
            {
                ok=0;
                break;
            }
    return ok;            
}

int main(int argc, char * argv[]) {
    int rank, nProcesses;

    MPI_Init(&argc, &argv);
	MPI_Status status;
	MPI_Request request;

	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	MPI_Comm_size(MPI_COMM_WORLD, &nProcesses);

    if ((nProcesses > 12)||(nProcesses <2)) {
		printf("please run with: mpirun --oversubscribe -np 2-12 %s\n", argv[0]);
		MPI_Finalize();	
		exit(0);
	}
	int vectorvalue[nProcesses];
    if(rank==0){
        for(int i = 0; i <nProcesses; i++)
            {
                vectorvalue[i]= atoi(argv[i+1]);
            }
            	if(vectorvalue[0]!=2)
   		if(prime(vectorvalue[0])==0)vectorvalue[0]=-1;
		MPI_Send(&vectorvalue,nProcesses,MPI_INT,(rank+1), 0, MPI_COMM_WORLD);
		}
	else if (rank<(nProcesses-1)){
	MPI_Recv(&vectorvalue, nProcesses, MPI_INT, (rank-1), 0, MPI_COMM_WORLD,MPI_STATUS_IGNORE);
		if(vectorvalue[rank]!=2)
		if(prime(vectorvalue[rank])==0)vectorvalue[rank]=-1;
	MPI_Send(&vectorvalue,nProcesses,MPI_INT,(rank+1), 0, MPI_COMM_WORLD);
		}
	else {
	MPI_Recv(&vectorvalue, nProcesses, MPI_INT, (rank-1), 0, MPI_COMM_WORLD,MPI_STATUS_IGNORE);
	if(vectorvalue[rank]!=2)
	if(prime(vectorvalue[rank])==0)vectorvalue[rank]=-1;
	int ok=0;
	for (int i=0;i<nProcesses;i++)
		if(vectorvalue[i]>0){
		printf("%i ",vectorvalue[i]);
		ok=1;
		}
		if(ok==0)printf("Nu estista numere prime in sir");
	}

    MPI_Finalize();
     return 0;
}
